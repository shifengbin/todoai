---
name: task-done
description: Use when 用户要求完成任务、收尾任务工作区、合并 base/worktree 分支、处理任务完成后的文档归档，或移除当前任务 worktree。
---

# Task Done

## Overview

完成任务工作区时，必须以根目录 `README.md` 为项目清单和分支来源，对每个子目录仓库执行同一套收尾流程：先把 base 合进 worktree，再把 worktree 合回 base，最后按需归档文档、移除当前 worktree 并删除 worktree 分支。

## Start

1. 在任务工作区根目录开始，即包含 `README.md` 和子目录仓库的目录。
2. 先读取 `README.md`，解析“项目信息”下的每个项目条目。
3. 对每个条目提取：
   - 子目录仓库名或路径，例如 `tui-helper`
   - base 分支或引用，例如 `origin/main`
   - 当前 worktree 分支，例如 `todo-workspace/tui-helper/<id>`
4. 如果 `README.md` 与实际 git 状态不一致，暂停并报告具体差异，不要猜测。

## Per Repository

对 `README.md` 里的每个子目录仓库逐个执行：

1. 进入仓库目录，记录当前状态：
   ```bash
   git status --short
   git branch --show-current
   git worktree list
   ```
2. 确认当前分支是 `README.md` 声明的 worktree 分支。若不是，只在工作区干净且目标明确时切换到该分支。
3. 合并前保证任务更改已经提交。若存在未提交更改：
   - 先确认它们属于当前任务。
   - 运行相关验证命令。
   - 提交任务更改，或在提交范围/信息不清楚时询问用户。
   - 不要为了方便合并而 `reset`、删除、覆盖、丢弃或随意 stash 用户更改。
4. 若 base 是远端引用，如 `origin/main`，先 fetch 对应远端。
5. 在 worktree 分支上合并 base：
   ```bash
   git merge <base-ref>
   ```
6. 如果出现冲突：
   - 打开所有冲突文件和相关 spec 文档。
   - 优先读取根目录或仓库内的 `openspec/` 文档，包括 proposal、design、tasks、spec delta。
   - 以 spec 文档判断任务期望行为，同时保留 base 上已有的有效改动。
   - 不要整体使用 `--ours` 或 `--theirs`，除非文件是生成物且理由明确。
   - 解决冲突后运行相关验证，`git add` 后继续合并。
7. 确认 worktree 分支已经包含 base，且验证通过。

## Merge Back To Base

1. 用 `git worktree list` 和分支追踪关系找到 base 分支所在 worktree。
2. 如果 base 是 `origin/main` 这类远端引用，目标 base 分支应是追踪它的本地分支，例如追踪 `origin/main` 的 `main`。若不存在本地追踪分支，再创建对应分支。
3. 进入或切换到 base 分支所在 worktree。
4. 先把 base 分支更新到 `README.md` 声明的 base 引用；对远端引用优先使用 fast-forward 更新。
5. 把 worktree 分支合并回 base：
   ```bash
   git merge <worktree-branch>
   ```
6. 如有冲突，按同样的 spec 文档策略解决。
7. 运行必要验证，并确认 base 分支 `git status --short` 干净。
8. 对 `README.md` 中每个子目录仓库重复以上步骤。

## Archive Docs

1. 只有在所有子目录仓库都已经合并回 base 后，才处理文档归档。
2. 如果存在 OpenSpec change 或任务文档需要归档，必须在对应仓库的 base 分支上归档。
3. 优先使用项目已有的 OpenSpec 归档流程或 `openspec-archive-change` 技能。
4. 如果无法确定应归档哪个 change，列出候选项并询问用户，不要猜测。

## Remove Worktree And Branch

1. 只有在 base 合并、验证、文档归档都完成后，才移除当前任务 worktree。
2. 从仓库外部执行移除，避免当前 shell 位于将被删除的目录中：
   ```bash
   git worktree remove <task-worktree-path>
   ```
3. 若移除失败，先检查是否还有未提交、未跟踪或未合并内容。不要强制删除，除非确认内容不再需要并得到用户许可。
4. worktree 移除成功后，确认 worktree 分支已合并进 base 且没有被其他 worktree 占用，然后删除本地 worktree 分支：
   ```bash
   git branch -d <worktree-branch>
   ```
5. 如果 `git branch -d` 提示分支未完全合并，暂停并报告，不要使用 `git branch -D`，除非用户明确确认要强制删除。
6. 不要删除远端 worktree 分支，除非 `README.md` 或用户明确要求。
7. 所有任务 worktree 和本地 worktree 分支移除后，可运行：
   ```bash
   git worktree prune
   ```

## Completion Report

完成或暂停时报告：

- 每个仓库的 base 引用、worktree 分支和 base 分支。
- base 合入 worktree 是否成功，是否有冲突。
- worktree 合回 base 是否成功，是否有冲突。
- 运行过的验证命令及结果。
- 文档是否归档，归档位置。
- 移除的 worktree 路径。
- 删除的本地 worktree 分支。
- 如果暂停，说明仓库、分支、命令、冲突文件或需要用户决策的问题。

## Common Mistakes

- 不要跳过“base 先合入 worktree”这一步直接合回 base。
- 不要只看 `AGENTS.md`；任务项目清单必须以 `README.md` 为准。
- 不要把远端引用当作可直接工作的本地 base 分支。
- 不要在冲突中脱离 spec 文档凭记忆选择代码。
- 不要在 worktree 分支尚未合回 base 前移除 worktree。
- 不要在 worktree 移除前删除它正在使用的分支。
